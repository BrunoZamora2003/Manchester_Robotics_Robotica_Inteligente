#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import math

class SquareController(Node):
    def __init__(self):
        super().__init__('square_controller')
        # Publicador en el tópico /cmd_vel para enviar comandos de movimiento.
        self.cmd_vel_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        # Periodo del timer (10 Hz)
        timer_period = 0.1  
        self.dt = timer_period
        self.timer = self.create_timer(timer_period, self.timer_callback)

        # Parámetros fijos para un cuadrado:
        # Se define la trayectoria como 4 tramos: ángulos (en radianes) y distancias fijas.
        # Para un cuadrado se utilizan giros de 90° (pi/2) excepto el primero, que es 0.
        self.angles = [0, math.pi/2, math.pi/2, math.pi/2]
        self.distances = [2, 2, 2, 2]

        # Variables para almacenar la configuración de cada tramo según la entrada del usuario
        self.segment_modes = []         # "tiempo" o "velocidad"
        self.segment_total_times = []   # Tiempo total T para recorrer el tramo
        self.segment_speeds = []        # Velocidad de crucero (calculada o dada)
        self.cruise_durations = []      # Tiempo de fase de crucero (T - 2, pues se dedican 1 s a acelerar y 1 s a desacelerar)
        self.initial_speed = 0.03       # Velocidad inicial para las rampas

        # Duración fija de las rampas y pausas (en segundos)
        self.accel_duration = 1.0     # Rampa de aceleración de 1 s
        self.decel_duration = 0.2     # Rampa de desaceleración de 1 s
        self.pause_duration = 0.5       # Pausa de 1 s tras el giro y al final del tramo

        # Para cada tramo (segmento), se solicita al usuario la modalidad y se realizan los cálculos correspondientes.
        for i in range(len(self.distances)):
            d = self.distances[i]
            # Mostrar el ángulo en grados para facilitar la lectura al usuario.
            ang_deg = math.degrees(self.angles[i])
            self.get_logger().info(f"Configurando tramo {i+1}: ángulo = {ang_deg:.2f}°, distancia = {d:.2f} m")
            mode = input(f"Tramo {i+1}: Ingrese el modo ('tiempo' o 'velocidad'): ").strip().lower()
            while mode not in ['tiempo', 'velocidad']:
                mode = input("Modo inválido. Ingrese 'tiempo' o 'velocidad': ").strip().lower()
            self.segment_modes.append(mode)
            if mode == 'tiempo':
                valid = False
                # En modo tiempo se solicita el tiempo total T (debe ser mayor que 1 s)
                while not valid:
                    try:
                        T = float(input(f"Tramo {i+1}: Ingrese el tiempo total (en segundos, >4) para recorrer el tramo: "))
                        if T <= 4:
                            self.get_logger().warn("El tiempo debe ser mayor que 1 segundo.")
                            continue
                        # Fórmula derivada: d = V*(T - 1) + 0.03  ->  V = (d - 0.03) / (T - 1)
                        V = (d - self.initial_speed) / (T - 1)
                        if V < 0.03 or V > 0.9:
                            self.get_logger().warn(f"Tramo {i+1}: La velocidad calculada es {V:.2f} m/s, fuera de límites [0.03, 0.9]. Ingrese otro tiempo.")
                        else:
                            valid = True
                    except ValueError:
                        self.get_logger().warn("Entrada inválida. Intente nuevamente.")
                self.segment_total_times.append(T)
                self.segment_speeds.append(V)
                # Tiempo de fase de crucero = T - (tiempo de aceleración + desaceleración) = T - 2.
                self.cruise_durations.append(T - (self.accel_duration + self.decel_duration))
                self.get_logger().info(f"Tramo {i+1} configurado: Modo tiempo, T = {T:.2f} s, V = {V:.2f} m/s, tiempo crucero = {T - 2:.2f} s.")
            else:  # modo velocidad
                valid = False
                # En modo velocidad se pide la velocidad deseada (entre 0.03 y 0.9 m/s)
                while not valid:
                    try:
                        V = float(input(f"Tramo {i+1}: Ingrese la velocidad deseada (en m/s) entre 0.03 y 0.9: "))
                        if V < 0.03 or V > 0.9:
                            self.get_logger().warn("Velocidad fuera de límites. Intente nuevamente.")
                            continue
                        valid = True
                    except ValueError:
                        self.get_logger().warn("Entrada inválida. Intente nuevamente.")
                # Se calcula el tiempo total T usando la fórmula: T = (d - 0.03)/V + 1
                T = (d - self.initial_speed) / V + 1
                self.segment_total_times.append(T)
                self.segment_speeds.append(V)
                self.cruise_durations.append(T - (self.accel_duration + self.decel_duration))
                self.get_logger().info(f"Tramo {i+1} configurado: Modo velocidad, V = {V:.2f} m/s, T = {T:.2f} s, tiempo crucero = {T - 2:.2f} s.")

        # Variables de control de la trayectoria
        self.index = 0                # Índice del tramo actual
        self.state = 0                # Estado de la máquina de estados (0 a 7)
        self.time_in_state = 0.0      # Tiempo acumulado en el estado actual
        self.last_logged_state = None # Para asegurar que se imprima un solo mensaje por estado

        # Parámetro para giros: velocidad angular fija.
        self.angular_speed = 0.5  # rad/s
        # Pre-cálculo de la duración de giro para cada tramo: angular_duration = |ángulo|/angular_speed.
        self.angular_durations = [abs(angle)/self.angular_speed for angle in self.angles]

        self.get_logger().info("Nodo square_controller inicializado y listo.")

    def log_state_message(self, state):
        # Función para imprimir (una vez) el mensaje correspondiente a cada estado.
        if self.last_logged_state != state:
            if state == 0:
                self.get_logger().info("Estado 0: Stop inicial")
            elif state == 1:
                # Mostrar el ángulo en grados
                ang_deg = math.degrees(self.angles[self.index])
                self.get_logger().info(f"Estado 1: Giro, ángulo = {ang_deg:.2f}°")
            elif state == 2:
                self.get_logger().info("Estado 2: Pausa post giro")
            elif state == 3:
                self.get_logger().info("Estado 3: Rampa de aceleración")
            elif state == 4:
                self.get_logger().info("Estado 4: Movimiento lineal a velocidad constante")
            elif state == 5:
                self.get_logger().info("Estado 5: Rampa de desaceleración")
            elif state == 6:
                self.get_logger().info("Estado 6: Pausa final del tramo")
            elif state == 7:
                self.get_logger().info("Estado 7: Stop final")
            self.last_logged_state = state

    def timer_callback(self):
        cmd = Twist()
        self.time_in_state += self.dt

        # Si se han completado todos los tramos, se detiene el robot y se cancela el timer.
        if self.index >= len(self.distances):
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.log_state_message(7)
            self.cmd_vel_publisher.publish(cmd)
            self.timer.cancel()
            return

        # Parámetros del tramo actual:
        current_V = self.segment_speeds[self.index]            # Velocidad de crucero para el tramo
        cruise_time = self.cruise_durations[self.index]          # Duración de la fase de crucero
        angular_duration = self.angular_durations[self.index]    # Duración del giro para este tramo

        # Máquina de estados:
        if self.state == 0:
            self.log_state_message(0)
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            # Se transita inmediatamente al estado 1 (giro)
            self.state = 1
            self.time_in_state = 0.0

        elif self.state == 1:
            self.log_state_message(1)
            # Estado de giro: si angular_duration > 0, se ejecuta el giro.
            if self.time_in_state < angular_duration:
                # Se gira en la dirección del ángulo (usando el signo del ángulo)
                cmd.angular.z = self.angular_speed * math.copysign(1, self.angles[self.index])
            else:
                self.state = 2
                self.time_in_state = 0.0

        elif self.state == 2:
            self.log_state_message(2)
            # Pausa post giro de 1 segundo.
            if self.time_in_state < self.pause_duration:
                cmd.angular.z = 0.0
            else:
                self.state = 3
                self.time_in_state = 0.0

        elif self.state == 3:
            self.log_state_message(3)
            # Rampa de aceleración: durante 1 s se aumenta la velocidad desde initial_speed hasta current_V.
            if self.time_in_state < self.accel_duration:
                delta_v = current_V - self.initial_speed
                speed = self.initial_speed + delta_v * (self.time_in_state / self.accel_duration)
                cmd.linear.x = speed
            else:
                cmd.linear.x = current_V
                self.state = 4
                self.time_in_state = 0.0

        elif self.state == 4:
            self.log_state_message(4)
            # Movimiento lineal a velocidad constante durante el tiempo de fase de crucero.
            if self.time_in_state < cruise_time:
                cmd.linear.x = current_V
            else:
                self.state = 5
                self.time_in_state = 0.0

        elif self.state == 5:
            self.log_state_message(5)
            # Rampa de desaceleración: durante 1 s se disminuye la velocidad de current_V a initial_speed.
            if self.time_in_state < self.decel_duration:
                delta_v = current_V - self.initial_speed
                speed = current_V - delta_v * (self.time_in_state / self.decel_duration)
                cmd.linear.x = max(self.initial_speed, speed)
            else:
                self.state = 6
                self.time_in_state = 0.0

        elif self.state == 6:
            self.log_state_message(6)
            # Pausa final del tramo de 1 s.
            if self.time_in_state < self.pause_duration:
                cmd.linear.x = 0.0
            else:
                # Pasar al siguiente tramo si existe, de lo contrario finalizar (estado 7)
                self.index += 1
                if self.index < len(self.distances):
                    self.state = 1  # Iniciar el siguiente tramo con el giro
                else:
                    self.state = 7
                self.time_in_state = 0.0

        elif self.state == 7:
            self.log_state_message(7)
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.timer.cancel()

        # Publicar el comando calculado en /cmd_vel.
        self.cmd_vel_publisher.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    mover = SquareController()
    rclpy.spin(mover)
    mover.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
