#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import math
import yaml

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')
        # Publicador para los waypoints en el tópico /pose
        self.pose_publisher = self.create_publisher(PoseStamped, 'pose', 10)
        self.timer_period = 0.1  # Se publicará un waypoint cada 0.5 s
        self.timer = self.create_timer(self.timer_period, self.publish_waypoint)
        
        # Definición de la trayectoria: vectores de ángulos y distancias para cada tramo.
        self.angles = [math.pi/6, math.pi/1.5, -math.pi/1.3, -math.pi/2]
        self.distances = [1.5, 1.5, 1.5, 1.5]
        
        # Listas para almacenar la configuración de cada tramo
        self.segment_modes = []     # "tiempo" o "velocidad"
        self.segment_times = []     # Tiempo total para recorrer el tramo (según entrada)
        self.segment_speeds = []    # Velocidad de crucero para recorrer el tramo
        
        # Consultar al usuario para definir cada tramo
        self.get_user_input()
        
        # Calcular los waypoints de la trayectoria basados en ángulos y distancias acumulativas
        self.waypoints = self.compute_waypoints()
        self.waypoint_index = 0
        
        # Guardar el plan en un archivo YAML para que el controlador lo utilice
        self.save_plan()
        
        self.get_logger().info('Nodo path_generator inicializado y listo.')

    def get_user_input(self):
        # Por cada tramo de la trayectoria, se consulta al usuario el modo y el parámetro (tiempo o velocidad)
        for i in range(len(self.distances)):
            ang_deg = math.degrees(self.angles[i])
            self.get_logger().info(f"Configurando tramo {i+1}: ángulo = {ang_deg:.2f} °, distancia = {self.distances[i]:.2f} m")
            mode = input(f"Para el tramo {i+1}, ingrese el modo ('tiempo' o 'velocidad'): ").strip().lower()
            while mode not in ['tiempo', 'velocidad']:
                mode = input("Modo inválido. Ingrese 'tiempo' o 'velocidad': ").strip().lower()
            self.segment_modes.append(mode)
            d = self.distances[i]
            if mode == 'tiempo':
                valid = False
                while not valid:
                    try:
                        T = float(input(f"Ingrese el tiempo total (en segundos, >1) para recorrer el tramo {i+1}: "))
                        if T <= 1:
                            self.get_logger().warn("El tiempo debe ser mayor que 1 segundo.")
                            continue
                        # Cálculo de velocidad requerida: V = (d - 0.03) / (T - 1)
                        V = (d - 0.03) / (T - 1)
                        if V < 0.03 or V > 0.9:
                            self.get_logger().warn(f"Para el tramo {i+1}, la velocidad calculada es {V:.2f} m/s, fuera de límites [0.03, 0.9]. Ingrese otro tiempo.")
                        else:
                            valid = True
                    except ValueError:
                        self.get_logger().warn("Entrada inválida. Intente nuevamente.")
                self.segment_times.append(T)
                self.segment_speeds.append(V)
                self.get_logger().info(f"Tramo {i+1}: Tiempo = {T:.2f} s, velocidad calculada = {V:.2f} m/s")
            else:  # Modo velocidad
                valid = False
                while not valid:
                    try:
                        V = float(input(f"Ingrese la velocidad deseada (en m/s) para el tramo {i+1} (entre 0.03 y 0.9): "))
                        if V < 0.03 or V > 0.9:
                            self.get_logger().warn("Velocidad fuera de límites. Intente nuevamente.")
                            continue
                        # Calcular el tiempo total: T = ((d - 0.03) / V) + 1
                        T = ((d - 0.03) / V) + 1
                        valid = True
                    except ValueError:
                        self.get_logger().warn("Entrada inválida. Intente nuevamente.")
                self.segment_times.append(T)
                self.segment_speeds.append(V)
                self.get_logger().info(f"Tramo {i+1}: Velocidad = {V:.2f} m/s, tiempo calculado = {T:.2f} s")

    def compute_waypoints(self):
        # Se calcula la posición y orientación acumulativa en la trayectoria
        waypoints = []
        x, y, yaw = 0.0, 0.0, 0.0
        # Waypoint inicial
        pose = self.create_pose_stamped(x, y, yaw)
        waypoints.append(pose)
        # Para cada tramo, se actualiza la orientación y la posición en consecuencia
        for angle, distance in zip(self.angles, self.distances):
            yaw += angle  # Actualizar orientación por el ángulo del tramo
            pose = self.create_pose_stamped(x, y, yaw)
            waypoints.append(pose)
            # Avanzar en la dirección actual
            x += distance * math.cos(yaw)
            y += distance * math.sin(yaw)
            pose = self.create_pose_stamped(x, y, yaw)
            waypoints.append(pose)
        return waypoints

    def create_pose_stamped(self, x, y, yaw):
        # Crea un mensaje PoseStamped con la posición (x,y) y orientación (convertida a cuaternión)
        pose_stamped = PoseStamped()
        pose_stamped.header.frame_id = "map"  # Frame de referencia (puede cambiarse según la configuración)
        pose_stamped.header.stamp = self.get_clock().now().to_msg()
        pose_stamped.pose.position.x = x
        pose_stamped.pose.position.y = y
        pose_stamped.pose.position.z = 0.0
        
        # Conversión simple de yaw a cuaternión (rotación solo en Z)
        qx = 0.0
        qy = 0.0
        qz = math.sin(yaw/2)
        qw = math.cos(yaw/2)
        pose_stamped.pose.orientation.x = qx
        pose_stamped.pose.orientation.y = qy
        pose_stamped.pose.orientation.z = qz
        pose_stamped.pose.orientation.w = qw
        return pose_stamped

    def publish_waypoint(self):
        # Publica secuencialmente cada waypoint en el tópico /pose para visualización o seguimiento
        if self.waypoint_index < len(self.waypoints):
            pose_msg = self.waypoints[self.waypoint_index]
            pose_msg.header.stamp = self.get_clock().now().to_msg()
            self.pose_publisher.publish(pose_msg)
            self.get_logger().info(f"Waypoint {self.waypoint_index+1} publicado.")
            self.waypoint_index += 1
        else:
            self.get_logger().info("Todos los waypoints han sido publicados.")
            self.timer.cancel()

    def save_plan(self):
        # Guarda el plan (por tramo: ángulo, distancia, modo, tiempo y velocidad) en un archivo YAML
        plan = []
        for i in range(len(self.distances)):
            segment = {
                'segment': i+1,
                'angle': self.angles[i],
                'distance': self.distances[i],
                'mode': self.segment_modes[i],
                'time': self.segment_times[i],
                'speed': self.segment_speeds[i]
            }
            plan.append(segment)
        with open('plan.yaml', 'w') as file:
            yaml.dump(plan, file)
        self.get_logger().info("Plan guardado en 'plan.yaml'.")

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Interrupción del teclado, cerrando nodo...")
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
