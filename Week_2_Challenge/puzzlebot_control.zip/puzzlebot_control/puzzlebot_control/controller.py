#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import math
import yaml
import os

class Controller(Node):
    def __init__(self):
        super().__init__('controller')
        # Publicador en /cmd_vel para enviar comandos de movimiento al robot
        self.cmd_vel_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer_period = 0.1   # 10 Hz
        self.dt = self.timer_period
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        
        # Velocidad angular fija para giros
        self.angular_speed = 0.5  # rad/s
        
        # Cargar el plan previamente guardado (asegúrese de que plan.yaml exista)
        self.plan = self.load_plan('plan.yaml')
        if not self.plan:
            self.get_logger().error("No se pudo cargar el plan. Cerrando nodo.")
            rclpy.shutdown()
            return
        
        # Extraer de cada segmento: ángulo, distancia, velocidad de crucero y tiempo total
        self.angles = [segment['angle'] for segment in self.plan]
        self.distances = [segment['distance'] for segment in self.plan]
        self.segment_speeds = [segment['speed'] for segment in self.plan]  # velocidad calculada o ingresada
        self.segment_times = [segment['time'] for segment in self.plan]    # tiempo total para cada tramo
        
        # Calcular la duración del giro para cada tramo (usando velocidad angular)
        self.angular_durations = [abs(angle) / self.angular_speed for angle in self.angles]
        
        # Configuración para la parte lineal:
        # - 1 s de rampa de aceleración (de 0.03 m/s a la velocidad deseada)
        # - 1 s de rampa de desaceleración (de la velocidad deseada a 0.03 m/s)
        # - La fase de crucero se calcula según la distancia restante
        self.accel_duration = 0.5   # segundos
        self.decel_duration = 0.5   # segundos
        self.initial_speed = 0.03   # m/s (velocidad inicial de las rampas)
        self.linear_cruise_durations = []
        for i, d in enumerate(self.distances):
            V = self.segment_speeds[i]
            # Distancia cubierta en aceleración: (initial_speed + V)/2 * 1
            # Lo mismo para desaceleración; en total se recorre: V + initial_speed
            ramp_distance = V + self.initial_speed
            cruise_distance = d - ramp_distance
            if cruise_distance < 0:
                cruise_time = 0.0
            else:
                cruise_time = cruise_distance / V
            self.linear_cruise_durations.append(cruise_time)
        
        # Definición de la máquina de estados:
        # 0: Stop inicial
        # 1: Giro
        # 2: Pausa post giro (1 s)
        # 3: Rampa de aceleración (1 s, de initial_speed a V)
        # 4: Movimiento lineal a velocidad constante (fase de crucero)
        # 5: Rampa de desaceleración (1 s, de V a initial_speed)
        # 6: Pausa final del tramo (1 s)
        # 7: Stop final (fin de la trayectoria)
        self.state = 0
        self.segment_index = 0  # tramo actual
        self.time_in_state = 0.0
        # Para asegurar la impresión única por estado
        self.last_logged_state = None

        self.get_logger().info("Nodo controller inicializado y listo.")
        
    def load_plan(self, filename):
        # Carga el plan desde un archivo YAML
        if not os.path.exists(filename):
            self.get_logger().error(f"El archivo {filename} no existe.")
            return None
        with open(filename, 'r') as file:
            plan = yaml.safe_load(file)
        self.get_logger().info("Plan cargado exitosamente desde 'plan.yaml'.")
        return plan
    
    def log_state_message(self, state):
        # Imprime un mensaje único cuando se entra a un nuevo estado
        if self.last_logged_state != state:
            if state == 0:
                self.get_logger().info("Estado 0: Stop inicial")
            elif state == 1:
                # Se muestra el ángulo en grados para el tramo actual
                angle_deg = math.degrees(self.angles[self.segment_index])
                self.get_logger().info(f"Estado 1: Giro, ángulo = {angle_deg:.2f}°")
            elif state == 2:
                self.get_logger().info("Estado 2: Pausa post giro")
            elif state == 3:
                self.get_logger().info("Estado 3: Rampa de aceleración")
            elif state == 4:
                self.get_logger().info("Estado 4: Movimiento lineal a velocidad constante")
            elif state == 5:
                self.get_logger().info("Estado 5: Rampa de desaceleración")
            elif state == 6:
                self.get_logger().info("Estado 6: Pausa final del tramo")
            elif state == 7:
                self.get_logger().info("Estado 7: Stop final")
            self.last_logged_state = state

    def timer_callback(self):
        cmd = Twist()
        self.time_in_state += self.dt
        
        # Verificar si ya se han procesado todos los tramos
        if self.segment_index >= len(self.distances):
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.log_state_message(7)
            self.cmd_vel_publisher.publish(cmd)
            self.timer.cancel()
            return
        
        # Datos del tramo actual:
        V = self.segment_speeds[self.segment_index]       # velocidad de crucero
        cruise_time = self.linear_cruise_durations[self.segment_index]  # duración de la fase de crucero
        angular_duration = self.angular_durations[self.segment_index]   # duración del giro
        
        # Máquina de estados:
        if self.state == 0:
            self.log_state_message(0)
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            # Se transita inmediatamente al estado 1 (giro)
            self.state = 1
            self.time_in_state = 0.0

        elif self.state == 1:
            self.log_state_message(1)
            # Estado 1: Giro
            if self.time_in_state < angular_duration:
                cmd.angular.z = self.angular_speed * math.copysign(1, self.angles[self.segment_index])
            else:
                self.state = 2
                self.time_in_state = 0.0

        elif self.state == 2:
            self.log_state_message(2)
            # Estado 2: Pausa tras el giro (1 s)
            if self.time_in_state < 1.0:
                cmd.angular.z = 0.0
            else:
                self.state = 3
                self.time_in_state = 0.0

        elif self.state == 3:
            self.log_state_message(3)
            # Estado 3: Rampa de aceleración (1 s, de initial_speed a V)
            if self.time_in_state < self.accel_duration:
                delta_v = V - self.initial_speed
                speed = self.initial_speed + delta_v * (self.time_in_state / self.accel_duration)
                cmd.linear.x = speed
            else:
                cmd.linear.x = V
                self.state = 4
                self.time_in_state = 0.0

        elif self.state == 4:
            self.log_state_message(4)
            # Estado 4: Movimiento lineal a velocidad constante (fase de crucero)
            if self.time_in_state < cruise_time:
                cmd.linear.x = V
            else:
                self.state = 5
                self.time_in_state = 0.0

        elif self.state == 5:
            self.log_state_message(5)
            # Estado 5: Rampa de desaceleración (reduce de V a initial_speed en 1 s)
            if self.time_in_state < self.decel_duration:
                delta_v = V - self.initial_speed
                speed = V - delta_v * (self.time_in_state / self.decel_duration)
                cmd.linear.x = max(self.initial_speed, speed)
            else:
                self.state = 6
                self.time_in_state = 0.0

        elif self.state == 6:
            self.log_state_message(6)
            # Estado 6: Pausa final del tramo (1 s)
            if self.time_in_state < 1.0:
                cmd.linear.x = 0.0
            else:
                # Pasar al siguiente tramo si existe; de lo contrario, finalizar trayectoria (estado 7)
                self.segment_index += 1
                if self.segment_index < len(self.distances):
                    self.state = 1  # Reiniciar con giro para el próximo tramo
                else:
                    self.state = 7
                self.time_in_state = 0.0

        elif self.state == 7:
            self.log_state_message(7)
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.timer.cancel()
        
        # Publicar el comando calculado en /cmd_vel
        self.cmd_vel_publisher.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = Controller()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Interrupción de teclado, cerrando nodo...")
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
