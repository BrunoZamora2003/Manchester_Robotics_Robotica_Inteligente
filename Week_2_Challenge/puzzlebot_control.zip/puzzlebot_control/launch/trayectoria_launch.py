#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessExit
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg = 'puzzlebot_control'
    param_path = os.path.join(
        get_package_share_directory(pkg),
        'config',
        'path_generator_params.yaml'
    )

    path_generator_node = Node(
        package=pkg,
        executable='path_generator',
        name='path_generator',
        output='screen',
        parameters=[param_path]
    )

    controller_node = Node(
        package=pkg,
        executable='controller',
        name='controller',
        output='screen'
    )

    controller_handler = RegisterEventHandler(
        OnProcessExit(
            target_action=path_generator_node,
            on_exit=[controller_node]
        )
    )

    return LaunchDescription([
        path_generator_node,
        controller_handler
    ])
