#!/usr/bin/env python3
"""
Instrucciones en terminal:

    colcon build --packages-select puzzletbot_control
    source install/setup.bash
    ros2 launch puzzletbot_control cuadrado_launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Nodo de control para recorrer el cuadrado
        Node(
            package='puzzlebot_control',
            executable='square_controller',
            name='square_controller',
            output='screen'
        ),
        # Nodo para visualizar el tópico /cmd_vel con rqt_plot
        Node(
            package='rqt_plot',
            executable='rqt_plot',
            name='rqt_plot',
            arguments=['/cmd_vel'],
            output='screen'
        ),
        # Nodo para visualizar la red de tópicos con rqt_graph
        Node(
            package='rqt_graph',
            executable='rqt_graph',
            name='rqt_graph',
            output='screen'
        )
    ])
